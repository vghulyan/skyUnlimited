To run this application either open the index.html in a browser or run through a local server.
If you are running a node js server make sure you've installed the required modules,

npm install express // checks where to look our index.html

If you are running using node then go to your browser and type
http:://localhost:3000
otherwise open the index.html in your browser

How to use the application
If you want to see the some tabled data then click on Refresh button
If you want to see the json data then select the checkbox

Note: I am displaing only a few tables: the Call Charge data and Subscriptions with their total.
